import { GenericData } from './generic';

export interface Location {
 latitude: GenericData,
 longitude: GenericData,
}
