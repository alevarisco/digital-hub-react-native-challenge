export interface GenericData {
    title: string,
    value: number
}
