export interface Brand {
    id?: number,
    nombre: string,
    descripcion: string,
    pais: string,
    tipo: string
    anioFundacion: number,
}
